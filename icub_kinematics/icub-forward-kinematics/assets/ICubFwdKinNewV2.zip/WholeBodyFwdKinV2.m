close all
clear all
wtheta = [0, 0, 0]*pi/180;
htheta = [0, 0, 0, 0, -30, 30]*pi/180;
ratheta = [ -25.8  20.0     0.0     50    0.0   0.0  40.0]*pi/180;
latheta = [ -25.8  20.0     0.0     50    0.0   0.0  40.0]*pi/180;
rltheta = [0, 0, 0, 0, 0, 0]*pi/180;
lltheta = [0, 0, 0, 0, 0, 0]*pi/180;


cd WaistHeadV2FwdKin;
WaistHeadFwdKin_HeadV2(wtheta,htheta, 1);
cd ..
cd WaistRightArmFwdKin;
WaistRightArmFwdKin(wtheta,ratheta, 1);
cd ..
cd WaistLeftArmFwdKin;
WaistLeftArmFwdKin(wtheta,latheta, 1);
cd ..
cd WaistLeftLegFwdKin;
WaistLeftLegFwdKin(lltheta,1);
cd ..
cd WaistRightLegFwdKin;
WaistRightLegFwdKin(rltheta,1);
cd ..
cd WaistInertiaV2FwdKin;
WaistInertiaFwdKinV2(wtheta,htheta(1:3), 1);
cd ..

% axis('equal')
% xlabel('x')
% xlim([-200 200]);
% ylabel('y')
% ylim([-200 200]);
% zlabel('z')
% zlim([-600 400]);